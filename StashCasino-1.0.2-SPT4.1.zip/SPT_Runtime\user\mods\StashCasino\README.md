# Stash Casino V1

## One-click build

Double-click `build.bat`. It now tries to find your SPT install automatically. If it cannot find it, a normal Windows folder picker opens so you can click the SPT folder instead of typing a path.

When the build succeeds it installs the client/server files into that SPT install and creates `ReleaseZip\StashCasino-1.0.2-SPT4.1.zip`.


A focused SPT 4.1.x client + server mod that lets you play **Blackjack** and **European Roulette** using actual roubles from your stash.

## V1 features

### Blackjack
* 6-deck shuffled shoe
* Dealer stands on soft 17
* Natural blackjack pays 3:2
* Hit, Stand, Double
* Minimum wager ₽10,000
* Maximum wager ₽5,000,000
* Active hand survives closing/reopening the casino window while the server stays running

### Roulette
* European single-zero wheel (0-36)
* Straight-up numbers: 35:1 profit (36x total return)
* Red / Black / Odd / Even / 1-18 / 19-36: 1:1 profit (2x total return)
* Chip presets from ₽10K to ₽1M
* ₽5M maximum combined stake per spin

## How it opens

Open your stash/out-of-raid item UI. A **CASINO** button appears in the upper-right corner. You can also press **F8** while the stash UI is available.

The casino is an overlay. You do not enter a raid, visit a trader, or use fake casino currency. Stakes and payouts come from rouble stacks actually stored in your stash. Roubles carried in equipment are deliberately ignored.

## Build / install

This client plugin must be compiled against the exact SPT install it will run on.

1. Install the .NET 10 SDK.
2. Open PowerShell in this source folder.
3. Run:

   `./build.ps1 -SptPath "C:\path\to\your\SPT"`

4. The script creates `StashCasino-1.0.2-SPT4.1.zip` and, unless `-NoInstall` is supplied, installs the two DLLs into that SPT install.
5. Start the SPT server and launcher normally.

## Install paths after build

`BepInEx/plugins/StashCasino/StashCasino.Client.dll`

`SPT_Runtime/user/mods/StashCasino/StashCasino.Server.dll`

## Current V1 limits

* Roubles only.
* No split or insurance in Blackjack yet.
* Blackjack table state is memory-only. Finish a live hand before restarting the SPT server.
* The V1 UI uses Unity IMGUI on purpose: fewer patches and fewer version-sensitive hooks than cloning Tarkov's taskbar UI.

## Troubleshooting

If the casino opens but money on the visible stash does not immediately change, close/reopen the stash once and check the server console. V1 sends a harmless item-event sync after money moves so SPT can apply the server-side profile changes to the running client.

## Credits / license

Stash Casino is MIT licensed. Architecture and profile-sync patterns were informed by Joel Hauser's MIT-licensed SPT-Casino project. See `THIRD_PARTY_NOTICES.md`.


## V1.0.2 UI toggle

- The top-right `CASINO` button stays visible while the stash UI is available.
- While open it changes to `HIDE CASINO`.
- The casino window also has a `HIDE` button.
- `F8` still toggles the window, and `Escape` still closes it.

## V1.0.2 button visibility

Press **F2** while the stash UI is available to hide or show the floating **CASINO / HIDE CASINO** button.

This only hides the button itself. The casino window can still be opened or closed with **F8**, so you can keep the stash screen completely clean and only bring the casino up when you want it.
